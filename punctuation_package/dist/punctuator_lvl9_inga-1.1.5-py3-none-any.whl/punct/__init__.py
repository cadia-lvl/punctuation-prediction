from __future__ import absolute_import

from .api import (
    punctuate,
)

__author__ = u"Language and Voice Lab at Reykjavik University"
__version__ = u"1.0.0"  